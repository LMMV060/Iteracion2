package es.tuespiral.spring.vehiculo;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import es.tuespiral.spring.cliente.ClientException;
import es.tuespiral.spring.cliente.Cliente;

@Service
public class VehiculoService {

	private VehiculoRepository repoV;

	public VehiculoService(VehiculoRepository cr) {
		repoV = cr;
	}

	public Iterable<Vehiculo> findAll() {
		return repoV.findAll();
	}

	public boolean existsByMatricla(String matricula) {
		boolean exist;
		if (repoV.findByMatricula(matricula) == null) {
			exist = false;
			return exist;
		} else {
			exist = true;
			return exist;
		}
	}

	public Vehiculo findByMatricula(String matricula) throws VehiException {
		List<Vehiculo> v = repoV.findByMatricula(matricula);

		if (v.isEmpty()) {
			throw new VehiException("El vehiculo  con matrícula = " + matricula + " no existe");
		} else {
			Vehiculo vh = v.get(0);
			System.out.println(vh);
			return vh;
		}

	}
	
	public Vehiculo findById(Long id) throws VehiException {
		Optional<Vehiculo> vh = repoV.findById(id);

		if (vh.isEmpty()) {
			throw new VehiException("El vehículo con ID = " + id + " no existe");
		} else {
			Vehiculo v = vh.get();
			System.out.println(v);
			return v;
		}
	}



}


