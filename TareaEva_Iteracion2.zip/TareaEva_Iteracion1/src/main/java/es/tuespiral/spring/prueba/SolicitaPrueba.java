package es.tuespiral.spring.prueba;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import es.tuespiral.spring.cliente.Cliente;
import es.tuespiral.spring.vehiculo.Vehiculo;
import lombok.Data;


@Entity	
@Table(name="Solicita_Prueba")
@Data

public class SolicitaPrueba {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
	
	@ManyToOne
	private Cliente cliente;
	
	@ManyToOne
	private Vehiculo vehiculo;
	
	
	@Column(name="testHour", nullable=true)
	private LocalTime testHour;
	
	@Column(name="testDate", nullable=true)
	private LocalDate testDate;
	
	@Column(name="realizaTest",length=50, nullable=true)
	private String realizaTest;
	
	

	public SolicitaPrueba() {
		super();
	}

	

	public SolicitaPrueba(Cliente cliente, Vehiculo vehiculo, LocalTime testHour, LocalDate testDate,
			String realizaTest) {
		super();
		
		this.cliente = cliente;
		this.vehiculo = vehiculo;
		this.testHour = testHour;
		this.testDate = testDate;
		this.realizaTest = realizaTest;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public LocalTime getTestHour() {
		return testHour;
	}

	public void setTestHour(LocalTime testHour) {
		this.testHour = testHour;
	}

	public LocalDate getTestDate() {
		return testDate;
	}

	public void setTestDate(LocalDate testDate) {
		this.testDate = testDate;
	}

	public String isRealizaTest() {
		return realizaTest;
	}

	public void setRealizaTest(String realizaTest) {
		this.realizaTest = realizaTest;
	}



	
	

}
