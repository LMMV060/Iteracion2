package es.tuespiral.spring;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import es.tuespiral.spring.modelo.*;


@SpringBootApplication
public class RelacionesJpaApplication {

	public static void main(String[] args) throws ClienteException {
		ApplicationContext context = SpringApplication.run(RelacionesJpaApplication.class, args);
		
		
		ClienteRepository newCliente = context.getBean(ClienteRepository.class);
		ConcesionarioRepository newConcesionario = context.getBean(ConcesionarioRepository.class);
		VehiculoRepository newVehiculo = context.getBean(VehiculoRepository.class);
		
		
		Cliente c = new Cliente("Alfredo", "Barca");
		
		c.setEmail("lmmv060@gmail.com");
		c.setFecha("20-20-20");
		c.setId((long)1);
		c.setNIF("49826060X");
		c.setTelefono(618381630);
		
		//c = newCliente.findById((long)1).get();
		
		Concesionario con = new Concesionario();
		con.setDireccion("C/Capitán Cala");
		con.setEmail("empresa@original.com");
		con.setFecha("20-20-20");
		con.setHorario("20:00 - 21:00");
		con.setId((long)1);
		con.setNombre("BearBikes");
		con.setTelefono(618381630);
		
		vehiculo v = new vehiculo();
		
		v.setAnyo(1990);
		v.setCilindrada("Se pone en numeros verdad?  190");
		v.setId((long)1);
		v.setMarca("marca");
		v.setMatricula("1234C");
		v.setModelo("modelo");
		v.setNum(123456);
		v.setPotencia(80);
		v.setPrecio(12000);
		
		newCliente.save(c);
		newConcesionario.save(con);
		newVehiculo.save(v);
		
		// ITERACION 2
		
		
		
		ClienteService ClienteService = context.getBean(ClienteService.class);
		
		ClienteService.listar();
		ClienteService.buscarNIF("49826060X");
		
		ClienteService.borrarPorNIF("49826060X");
		ClienteService.newCliente((long)2, "Alberto", "El chocolatero", "4982600X", 123456789, "20-20-19", null);
		ClienteService.newCliente((long)3, "Marta", "Vega", "12345678X", 123456789, "20-20-19", null);
		ClienteService.actualizarCliente((long)2, "Pedro", "aaaaaaaaaaaaa", "21211221A", 0, "", null);
		//ClienteService.solicitarPrueba((long)1, "14-12-2002-19:00");
		
		
	}

}
