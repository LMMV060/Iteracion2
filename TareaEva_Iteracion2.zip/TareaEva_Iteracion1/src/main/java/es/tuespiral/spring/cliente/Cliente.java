package es.tuespiral.spring.cliente;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import es.tuespiral.spring.prueba.SolicitaPrueba;
import lombok.Data;

@Entity	
@Table(name="cliente")
@Data


public class Cliente {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
	
	@Column(name="nif", length=9, nullable=true, unique=true)
	private String nif;
	
	@Column(name="name", length=150, nullable=true, unique=false)
	private String name;
	
	@Column(name="lastName", length=150, nullable=true, unique=false)
	private String lastName;
	

	@Column(name="phoneNumber", nullable=true)
	private long phoneNumber;
	
	@Column(name="emailAddress", length=250, nullable=true)
	private String emailAddress;
	
	@Column(name="date", nullable=true)
	private LocalDate date;
	
	
	@OneToMany(mappedBy="cliente")
	private List<SolicitaPrueba> solictaPrueba = new ArrayList<>();
	
	
	public Cliente() {
		super();
	}
	
	

	public Cliente( String nif, String name, String lastName, long phoneNumber, String emailAddress,
			LocalDate date) {
		super();
		this.nif = nif;
		this.name = name;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
		this.date = date;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}



	public List<SolicitaPrueba> getSolictaPrueba() {
		return solictaPrueba;
	}



	public void setSolictaPrueba(List<SolicitaPrueba> solictaPrueba) {
		this.solictaPrueba = solictaPrueba;
	}

	

}
