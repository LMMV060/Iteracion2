package es.tuespiral.spring.modelo;

public class ClienteException extends Exception{
	public ClienteException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClienteException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ClienteException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ClienteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ClienteException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
