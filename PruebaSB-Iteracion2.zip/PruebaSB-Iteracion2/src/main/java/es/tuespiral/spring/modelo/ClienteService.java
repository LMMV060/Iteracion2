package es.tuespiral.spring.modelo;


import org.springframework.stereotype.Service;
import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;    
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;    




@Service
public class ClienteService {
	private ClienteRepository newCliente;
	private VehiculoRepository newVehiculo;
	
	
	
	public ClienteService(ClienteRepository cr) {
		newCliente = cr;
	}
	
	
	public void listar() {
		System.out.println(newCliente.findAll());
	}
	
	public void buscarNIF(String NIF) throws ClienteException {
		
		if(newCliente.findByNIF(NIF).isEmpty()) {
			throw new ClienteException("Error, el NIF no se encontro");
		} else {
			System.out.println(newCliente.findByNIF(NIF));
		}
	}
	
	
	public void borrarPorNIF(String NIF) throws ClienteException {
		
		if(newCliente.findByNIF(NIF).isEmpty()) {
			throw new ClienteException("Error, el NIF no se encontró");
		} else {
			System.out.println("Se ha borrado el cliente con el NIF " + NIF);
			newCliente.findByNIF(NIF).forEach(cliente ->{
				 newCliente.deleteById(cliente.getId());
			});
			
			
		}
	}
	
	public void newCliente(Long id, String Nombre, String Apellidos, String NIF, int Telefono, String Fecha, String Email) throws ClienteException {
		Cliente c = new Cliente(Nombre, Apellidos);
		c.setEmail(Email);
		c.setFecha(Fecha);
		c.setId(id);
		c.setNIF(NIF);
		c.setTelefono(Telefono);
		if(newCliente.findByNIF(NIF).isEmpty()) {
			newCliente.save(c);
		} else {
			throw new ClienteException("Error, el ID ya existe");
		}
	}
	
	public void actualizarCliente(Long id, String Nombre, String Apellidos, String NIF, int Telefono, String Fecha, String Email) throws ClienteException {
		Cliente c = new Cliente(Nombre, Apellidos);
		c.setEmail(Email);
		c.setFecha(Fecha);
		c.setId(id);
		c.setNIF(NIF);
		c.setTelefono(Telefono);
		if(newCliente.findById(id).isEmpty()) {
			throw new ClienteException("Error, el ID no existe");
		} else {
			newCliente.save(c);
		}
	}
	
	public void solicitarPrueba(Long IDCliente, Long IDCoche, String Fecha_Hora) throws ClienteException {
		if(newCliente.findById(IDCliente).isEmpty() || newVehiculo.findById(IDCoche).isEmpty()) {
			throw new ClienteException("Error, el ID no existe");
		} else {
			
		}
	}
	
	public void realizarPrueba(Long IDCliente, Long IDCoche, String Fecha_Hora) throws ClienteException {
		if(newCliente.findById(IDCliente).isEmpty() || newVehiculo.findById(IDCoche).isEmpty()) {
			throw new ClienteException("Error, el ID no existe");
		} else {
			
		}
	}
	
}
