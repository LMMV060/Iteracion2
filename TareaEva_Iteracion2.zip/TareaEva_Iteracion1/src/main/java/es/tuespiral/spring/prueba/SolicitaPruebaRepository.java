package es.tuespiral.spring.prueba;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import es.tuespiral.spring.cliente.Cliente;
import es.tuespiral.spring.vehiculo.Vehiculo;




@Repository
public interface SolicitaPruebaRepository extends CrudRepository <SolicitaPrueba, Long>{
	
//	public List <SolicitaPrueba> findByClient(Cliente c);
//	public List <SolicitaPrueba> findByVehiculo(Vehiculo v);

}
