package es.tuespiral.spring.modelo;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.ui.ModelMap;



@Entity	
@Table(name="CLIENTE")
public class Cliente {
	private boolean probando = false;

	public Cliente(String nombre, String apellidos) {
		
		Nombre = nombre;
		this.apellidos = apellidos;

	}

	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	private String Nombre;
	
	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	@Column(length=9, nullable=true, unique=true)
	private String NIF;
	
	public String getNIF() {
		return NIF;
	}

	public void setNIF(String nIF) {
		NIF = nIF;
	}

	@Column(length=150, nullable=false, unique=false)
	private String apellidos;
	
	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	@Column(name="EMAIL", length=250, nullable=true)
	private String email;
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	@Column(length=9, nullable=false, unique=false)
	private int telefono;

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	
	@Column(name="Fecha_de_alta", length=150, nullable=false, unique=false)
	private String fecha;

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Cliente() {
		
	}
	
	public boolean solicitaPrueba(String fecha, String hora) {
		probando = true;
		return probando;
	}
	
	
}
