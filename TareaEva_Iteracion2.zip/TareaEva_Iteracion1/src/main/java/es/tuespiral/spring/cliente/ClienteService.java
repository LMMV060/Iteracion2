package es.tuespiral.spring.cliente;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.tuespiral.spring.prueba.SolicitaPrueba;
import es.tuespiral.spring.prueba.SolicitaPruebaException;
import es.tuespiral.spring.prueba.SolicitaPruebaRepository;
import es.tuespiral.spring.vehiculo.Vehiculo;
import es.tuespiral.spring.vehiculo.VehiculoRepository;
import lombok.NonNull;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepository repoCli;
	@Autowired
	private VehiculoRepository repoVeh;
	@Autowired
	private SolicitaPruebaRepository repoPrueba;

	public Iterable<Cliente> findAll() {

		return repoCli.findAll();
	}

	public Cliente createCliente(@NonNull String name, @NonNull String nif, @NonNull String lastName,
			@NonNull long phoneNumber, @NonNull String emailAddress, @NonNull LocalDate date) throws ClientException {
		if (repoCli.existsByNif(nif)) {
			throw new ClientException("El cliente de  " + nif + " no es válido");
		}

		Cliente cl = new Cliente(nif, name, lastName, phoneNumber, emailAddress, date);
		repoCli.save(cl);

		return cl;
	}

	public Cliente updateClient(@NonNull long id, @NonNull String name, @NonNull String nif, @NonNull String lastName,
			@NonNull long phoneNumber, @NonNull String emailAddress, @NonNull LocalDate date) throws ClientException {
		Optional<Cliente> cl = repoCli.findById(id);
		if (cl.isEmpty()) {
			throw new ClientException("El cliente de  " + id + " no existía");
		} else {
			Cliente c = cl.get();
			c.setName(name);
			c.setLastName(lastName);
			c.setNif(nif);
			c.setPhoneNumber(phoneNumber);
			c.setDate(date);
			c.setEmailAddress(emailAddress);
			repoCli.save(c);
			System.out.println("Cliente con " + c.getNif() + " creado");
			return c;
		}
	}

	public void deleteByNif(@NonNull String nif) throws ClientException {

		List<Cliente> c = repoCli.findByNif(nif);

		if (!repoCli.existsByNif(nif)) {
			throw new ClientException("El cliente de  " + nif + " no existía");
		} else {
			Cliente cl = c.get(0);
			repoCli.delete(cl);
			System.out.println("Cliente con nif: " + nif + " borrado");

		}

	}

	public Cliente findById(Long id) throws ClientException {
		Optional<Cliente> cl = repoCli.findById(id);

		if (cl.isEmpty()) {
			throw new ClientException("El cliente con ID = " + id + " no existe");
		} else {
			Cliente c = cl.get();
			System.out.println(c);
			return c;
		}
	}

	public Cliente findByNif(String nif) throws ClientException {
		List<Cliente> cl = repoCli.findByNif(nif);

		if (cl.isEmpty()) {
			throw new ClientException("El cliente con ID = " + nif + " no existe");
		} else {
			Cliente c = cl.get(0);
			System.out.println(c.getName() + " " + c.getLastName() + " " + c.getNif() + " " + c.getEmailAddress());
			return c;
		}
	}


	public boolean existsByNif(String nif) {
		boolean exist;
		if (repoCli.findByNif(nif) == null) {
			exist = false;
			return exist;
		} else {
			exist = true;

			return exist;
		}
	}



	public SolicitaPrueba createPrueba(@NonNull LocalTime testHour, @NonNull LocalDate testDate,
			 @NonNull Long id_cliente, @NonNull Long id_vehiculo)
			throws SolicitaPruebaException {
		Optional<Cliente> cl = repoCli.findById(id_cliente);
		Optional<Vehiculo> vl = repoVeh.findById(id_vehiculo);
		if (repoCli.findById(id_cliente)==null) {
			throw new SolicitaPruebaException("El cliente de  " + id_cliente + " no existe");

		}
		if (repoVeh.findById(id_vehiculo )== null) {
			throw new SolicitaPruebaException("El vehículo  de  " + id_vehiculo + " no existe");

		}
		SolicitaPrueba sp = new SolicitaPrueba();
		sp.setTestHour(testHour);
		sp.setTestDate(testDate);
		sp.setCliente(cl.get());
		sp.setVehiculo(vl.get());
		sp.setRealizaTest("Pendiente");
		repoPrueba.save(sp);
		System.out.println("Registrada nueva prueba con id: " + sp.getId() + " para el día " 
				+ sp.getTestDate() + " a la hora " + sp.getTestHour() + " por el cliente de nif " +sp.getCliente().getNif() + 
				 " para el vehículo de matrícula " + sp.getVehiculo().getMatricula());
		return sp;
	}


	public SolicitaPrueba pruebaRealizada(@NonNull Long id_cliente, @NonNull Long id_vehiculo, @NonNull Long id_prueba)
			throws SolicitaPruebaException {
		Optional<Cliente> cl = repoCli.findById(id_cliente);
		Optional<Vehiculo> vl = repoVeh.findById(id_vehiculo);
		Optional<SolicitaPrueba> sp = repoPrueba.findById(id_prueba);
		if (repoCli.findById(id_cliente)==null) {
			throw new SolicitaPruebaException("El cliente de  " + id_cliente + " no existe");

		}
		if (repoVeh.findById(id_vehiculo )== null) {
			throw new SolicitaPruebaException("El vehículo  de  " + id_vehiculo + " no existe");

		}
		 SolicitaPrueba test = sp.get();
		test.setRealizaTest("Realizada");
		repoPrueba.save(test);
		System.out.println("Prueba realizada");
		return test;
	}

}
