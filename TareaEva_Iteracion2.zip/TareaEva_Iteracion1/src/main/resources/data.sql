Insert Into cliente (id, name, last_name, nif, email_address, DATE, phone_number) VALUES (7,'Alfredo', 'Bueno', '55550550D', "alberto@hotmailc.om",'2022-11-30', 9540000000);
Insert Into cliente (id, name, last_name, nif, email_address, DATE, phone_number) VALUES (8,'Antonio', 'Regular', '55450550D', "antonio@hotmailc.om",'2022-11-30', 9540000000);
Insert Into cliente (id, name, last_name, nif, email_address, DATE, phone_number) VALUES (10,'Alfredo', 'Malo', '65550550D', "juan@hotmailc.om",'2022-11-30', 9540000000);


insert into concesionario (id, name, email_address, mailing_address, opening_hours, phone_number, year) values (1, "Pepito concesiorio", "perpitp@gmail.uk", "C/ Sin numero", '08:00:00',954001345,2015);

insert into vehiculo (id, marca, modelo, matricula, potencia, cilindro, concesionario_id, bastidor, anyo_fabricacion, precio) values(1, "Opel", "Corsa", "4578CCC","150CV", 16, 1,4567890, 2022, 15000);
insert into vehiculo (id, marca, modelo, matricula, potencia, cilindro, concesionario_id, bastidor, anyo_fabricacion, precio) values(2, "Opel", "Astra", "5578CCC","180CV", 16, 1,4564490, 2021, 17500);

insert into solicita_prueba (id, realiza_test, test_date, test_hour, cliente_id, vehiculo_id) values (1, "No", '2022-12-01','10:00:00', 7,2);