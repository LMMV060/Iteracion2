package es.tuespiral.spring.vehiculo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface VehiculoRepository extends CrudRepository <Vehiculo, Long>{
	public List<Vehiculo> findByMatricula(String matricula);
	public boolean existsByMatricula(String matricula);
	public Optional<Vehiculo> findById(Long id);

}
