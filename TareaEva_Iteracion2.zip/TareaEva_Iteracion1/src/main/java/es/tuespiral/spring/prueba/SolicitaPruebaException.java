package es.tuespiral.spring.prueba;

public class SolicitaPruebaException  extends Exception{

	public SolicitaPruebaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SolicitaPruebaException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SolicitaPruebaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SolicitaPruebaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SolicitaPruebaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
