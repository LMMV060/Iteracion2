package es.tuespiral.spring;

import java.time.LocalDate;
import java.time.LocalTime;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import es.tuespiral.spring.cliente.ClientException;
import es.tuespiral.spring.cliente.Cliente;
import es.tuespiral.spring.cliente.ClienteRepository;
import es.tuespiral.spring.cliente.ClienteService;
import es.tuespiral.spring.concesionario.Concesionario;
import es.tuespiral.spring.concesionario.ConcesionarioRepository;
import es.tuespiral.spring.prueba.SolicitaPrueba;
import es.tuespiral.spring.prueba.SolicitaPruebaException;
import es.tuespiral.spring.prueba.SolicitaPruebaRepository;
import es.tuespiral.spring.prueba.SolicitaPruebaService;
import es.tuespiral.spring.vehiculo.VehiException;
import es.tuespiral.spring.vehiculo.Vehiculo;
import es.tuespiral.spring.vehiculo.VehiculoRepository;
import es.tuespiral.spring.vehiculo.VehiculoService;

@SpringBootApplication
public class Application {
	public static void main(String[] args) throws ClientException, SolicitaPruebaException, VehiException {
		ApplicationContext context = SpringApplication.run(Application.class, args);

		ClienteService serviceCliente = context.getBean(ClienteService.class);
		VehiculoService serviceVeh = context.getBean(VehiculoService.class);
		VehiculoRepository newVehiculo = context.getBean(VehiculoRepository.class);
		LocalDate dayTest = LocalDate.parse("2002-11-13");
		LocalDate dayTest1 = LocalDate.parse("2043-12-14");
		LocalTime timeTest = LocalTime.of(11, 00, 00);

		Long id_cliente = (long) 1;
		Long  id_vehiculo=(long) 1;
		Long  id_test=(long) 1;
		String matricula = "1234ABC";
	
		
	
		serviceCliente.createCliente("Luis", "49826060X","Sevilla" , 618381630, "nosexd@gmail.com", dayTest);
		serviceCliente.createCliente("Marta", "12345678A","Cadiz" , 123456789, "afhdsjkg@gmail.com", dayTest1);
		serviceCliente.findAll();
		serviceCliente.findByNif("49826060X");
		serviceCliente.updateClient(2, "Sara", "55550550D","Lmao" , 987654321, "fshvlkfbnj@gmail.com", dayTest1);
		serviceCliente.findByNif("49826060X");
		//serviceCliente.deleteByNif("49826060X");
		//serviceCliente.findByNif("49826060X");
		serviceCliente.findByNif("55550550D");
		
		Vehiculo veh = new Vehiculo();
		veh.setMatricula(matricula);
		newVehiculo.save(veh);
		serviceVeh.findByMatricula("1234ABC");
		serviceVeh.findById(id_vehiculo);
		serviceCliente.createPrueba(timeTest,dayTest,id_cliente,id_vehiculo); 
		serviceCliente.pruebaRealizada(id_cliente, id_vehiculo, id_test);
		
  }
	


}
