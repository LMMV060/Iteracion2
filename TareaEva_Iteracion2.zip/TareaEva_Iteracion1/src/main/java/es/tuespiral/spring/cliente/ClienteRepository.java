package es.tuespiral.spring.cliente;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;





@Repository
public interface ClienteRepository  extends CrudRepository<Cliente, Long>{
	public List <Cliente> findByNif(String nif);
	public List <Cliente> deleteByNif(String nif);
	public boolean existsByNif(String nif);
}
