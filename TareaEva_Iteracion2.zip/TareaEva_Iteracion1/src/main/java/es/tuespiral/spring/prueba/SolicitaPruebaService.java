package es.tuespiral.spring.prueba;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.tuespiral.spring.cliente.Cliente;
import es.tuespiral.spring.cliente.ClienteRepository;
import es.tuespiral.spring.vehiculo.Vehiculo;
import es.tuespiral.spring.vehiculo.VehiculoRepository;
import lombok.NonNull;

@Service
public class SolicitaPruebaService {
	
	@Autowired
	private ClienteRepository repoClient;
	@Autowired
	private VehiculoRepository repoV;
	@Autowired
	private SolicitaPruebaRepository repoPrueba;
	
//	public SolicitaPruebaService(SolicitaPruebaRepository pr) {
//	repoPrueba = pr;
//	}
//
//	public SolicitaPrueba findByClient(Cliente c) throws SolicitaPruebaException {
//		List<SolicitaPrueba> sp =repoPrueba.findByClient(c);
//		if(sp.isEmpty()) {
//			throw new SolicitaPruebaException("La prueba para el Cliente de Nif "+ c.getNif());
//		}else {
//			SolicitaPrueba test = sp.get(0);
//			return test;
//		}
//		
//		
//	}

}
