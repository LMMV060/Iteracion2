package es.tuespiral.spring.concesionario;


import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import es.tuespiral.spring.vehiculo.Vehiculo;

@Entity	
@Table(name="Concesionario")


public class Concesionario {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
	
	
	
	@Column(name="name", length=150, nullable=true, unique=true)
	private String name;
	
	@Column(name="emailAddress", length=250, nullable=true)
	private String emailAddress;
	
	@Column(name="mailingAddress", length=250, nullable=true)
	private String mailingAddress;

	@Column(name="year", nullable=true)
	private int year;
	
	@Column(name="openingHours", nullable=true)
	private LocalTime openingHours;
	
	@Column(name="phoneNumber", nullable=true)
	private long phoneNumber;
	
	@OneToMany(mappedBy="concesionario", fetch = FetchType.EAGER)
	private Set<Vehiculo> vehiculos = new HashSet<>();
	
	

	public Concesionario() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMailingAddress() {
		return mailingAddress;
	}

	public void setMailingAddress(String mailingAddress) {
		this.mailingAddress = mailingAddress;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public LocalTime getOpeningHours() {
		return openingHours;
	}

	public void setOpeningHours(LocalTime openingHours) {
		this.openingHours = openingHours;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Set<Vehiculo> getVehiculos() {
		return vehiculos;
	}

	public void setVehiculos(Set<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}

	
	
	
	
}
