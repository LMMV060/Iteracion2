package es.tuespiral.spring.vehiculo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import es.tuespiral.spring.concesionario.Concesionario;
import es.tuespiral.spring.prueba.SolicitaPrueba;

@Entity	
@Table(name="Vehiculo")

public class Vehiculo {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
	
	@Column(name="bastidor", nullable=false, unique=true)
	private long bastidor;
	
	@Column(name="matricula", length=7, nullable=false, unique=true)
	private String matricula;
	
	@Column(name="marca", length=50, nullable=true, unique=false)
	private String marca;
	
	@Column(name="modelo", length=150, nullable=true, unique=false)
	private String modelo;
	
	@Column(name="potencia", length=150,nullable=true, unique= false)
	private String potencia;
	
	@Column(name="cilindro", nullable=true, unique= false)
	private int cilindro;
	
	@Column(name="precio", nullable=true, unique= false)
	private long precio;
	
	@Column(name="anyoFabricacion", nullable=true, unique= false)
	private int anyoFabricacion;
	
	@ManyToOne
	private Concesionario concesionario;

	@OneToMany(mappedBy="vehiculo")
	private List<SolicitaPrueba> solictaPrueba = new ArrayList<>();
	
	public Vehiculo() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getBastidor() {
		return bastidor;
	}

	public void setBastidor(long bastidor) {
		this.bastidor = bastidor;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getPotencia() {
		return potencia;
	}

	public void setPotencia(String potencia) {
		this.potencia = potencia;
	}

	public int getCilindro() {
		return cilindro;
	}

	public void setCilindro(int cilindro) {
		this.cilindro = cilindro;
	}

	public long getPrecio() {
		return precio;
	}

	public void setPrecio(long precio) {
		this.precio = precio;
	}

	public int getAnyoFabricacion() {
		return anyoFabricacion;
	}

	public void setAnyoFabricacion(int anyoFabricacion) {
		this.anyoFabricacion = anyoFabricacion;
	}
	
	

	public Concesionario getConcesionario() {
		return concesionario;
	}

	public void setConcesionario(Concesionario concesionario) {
		this.concesionario = concesionario;
	}

	public List<SolicitaPrueba> getSolictaPrueba() {
		return solictaPrueba;
	}

	public void setSolictaPrueba(List<SolicitaPrueba> solictaPrueba) {
		this.solictaPrueba = solictaPrueba;
	}

	
	
	
}
